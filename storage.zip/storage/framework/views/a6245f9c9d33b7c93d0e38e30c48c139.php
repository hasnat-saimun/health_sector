

<?php $__env->startSection('body'); ?>
<div class="row ">
    <div class="col-6">
        <div class="card">
            <div class="row">
                <div class="col-12 mt-2">
                    <div class="alert alert-success mx-2 ">
                        <div class="row text-center">
                            <div class="col-12  my-1"><i class="fa-solid bg-rounded fa-user fa-lg bg-light px-2 py-3 rounded"></i></div>
                            <h6 class="text-uppercase mb-0">Vit Professional</h6>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <table class="table ">
                        <tbody class="">
                            <tr>
                                <th ><h5>হাসপাতাল নাম</h5></th>
                                <td><h5>vit Professional</h5></td>
                            </tr>
                            <tr>
                                <th ><h5>মোবাইল নম্বর</h5></th>
                                    <td><h5>01755048017</h5></td>
                                </tr>
                            <tr>
                                <th ><h5>ঠিকানা</h5></th>
                                <td><h5>cumilla</h5></td>
                                </tr>
                            <tr>
                                <th ><h5>ইমেইল<h5></th>
                                <td><h5>sadakmoha55@gmail.com</h5></td>
                                </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 ">
        <div class="card">
           <div class="row">
                <div class="col-12 mt-2">
                    <div class="alert alert-success mx-2 ">
                        <div class="row text-center">
                            <div class="col-12  my-1"><i class="fa-solid bg-rounded fa-user fa-lg bg-light px-2 py-3 rounded"></i></div>
                            <h6 class="text-uppercase mb-0">Vit Professional</h6>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <table class="table ">
                        <tbody class="">
                            <tr>
                                <th ><h5>হাসপাতাল নাম</h5></th>
                                <td><h5>vit Professional</h5></td>
                            </tr>
                            <tr>
                                <th ><h5>মোবাইল নম্বর</h5></th>
                                    <td><h5>01755048017</h5></td>
                                </tr>
                            <tr>
                                <th ><h5>ঠিকানা</h5></th>
                                <td><h5>cumilla</h5></td>
                                </tr>
                            <tr>
                                <th ><h5>ইমেইল<h5></th>
                                <td><h5>sadakmoha55@gmail.com</h5></td>
                                </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('nav&fotter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('navModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\health_sector\resources\views/hospital/hospitalList.blade.php ENDPATH**/ ?>